public enum Identification {
    HUMAN,
    SATELLITE,
    SENSOR
}
