import { useState } from "react";


function BodyDeletarReceita(){


    return(
        <main>
            <h2>Deletar Receita</h2>
        </main>
    );
};

export default BodyDeletarReceita;