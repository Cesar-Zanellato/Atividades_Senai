import { useState } from 'react';
import './Hearder.css'

function Hearder() {

    return(
        <main>
            <section>
                <h1>
                    Receituario 2.0
                </h1>
            </section>
            <section>
                <h2>
                    CRUD de Receitas Culinarias
                </h2>
            </section>
        </main>
    )
}

export default Hearder;