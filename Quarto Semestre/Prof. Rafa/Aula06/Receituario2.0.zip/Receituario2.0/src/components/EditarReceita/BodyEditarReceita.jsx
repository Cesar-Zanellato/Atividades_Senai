
function BodyEditarReceita(){

    return(
        <main>
            <h1>Editar Receita</h1>
        </main>
    );
};

export default BodyEditarReceita;